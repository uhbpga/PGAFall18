﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicCombat : MonoBehaviour {

    // Use this for initialization
    public static int CombatStatus;
    private int PlayerLife;
    private int EnemyLife;
    private int mCounter;
    public GameObject MyEnemy;
    //public void ChangeStatus(int);

	void Start () {
        //CombatStatus = 1;
        PlayerLife = 2;
        EnemyLife = 2;
        mCounter = 0;
    }
	
	// Update is called once per frame
	void FixedUpdate() {
        if (CombatStatus == 1)
        {
            Debug.Log("Combat with enemy mode");
            mCounter += 1;
            if (mCounter >= 100)
            {
                Debug.Log("Enemy Hit Player");
                mCounter = 0;
                PlayerLife -= 1;
                if (PlayerLife <= 0)
                {
                    Debug.Log("Player is Dead");
                }
            }
        }
        if (CombatStatus == 2)
        {
            Debug.Log("Normal Mode");
        }
        
	}
    private void Update()
    {
        if (CombatStatus == 1 && Input.GetKeyDown(KeyCode.H))
        {
            Debug.Log("Player Hit Enemy");
            EnemyLife -= 1;
            Debug.Log("Enemy life Reduced");
        }
        if (EnemyLife <= 0)
        {
            Debug.Log("Enemy is Dead");
        }
    }
    public void ChangeStatus(int a)
    {
        CombatStatus = a;
    }
}
